SBL 1.0 resolved page rendering package
Render target: CH9-P001
Entry file: CH9-P001.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zorna-expression-sheet.png
  Assets/Midori-Expression-Sheet.png
  Assets/Zorna-character-sheet.png
  Assets/Midori-Character-Reference-Sheet.png
  Assets/Midori-Canonical-Character-Specification.txt
  Assets/Zorna-canonical-character-specification(1).txt
  Assets/SRA-production-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
