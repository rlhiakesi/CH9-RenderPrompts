SBL 1.0 resolved page rendering package
Render target: CH9-P023
Entry file: CH9-P023.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zorna-canonical-character-specification(1).txt
  Assets/Temple-of-Light-Evolution-Sheet.png
  Assets/Zorna-character-sheet.png
  Assets/Temple-Clothing-Evolution-Sheet.png
  Assets/Zorna-expression-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
