SBL 1.0 resolved page rendering package
Render target: CH9-P037
Entry file: CH9-P037.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Midori-Expression-Sheet.png
  Assets/Midori-Canonical-Character-Specification.txt
  Assets/Midori-Character-Reference-Sheet.png
  Assets/Resurrection-Watch-Alpha.png
  Assets/Resurrection-Circle-State-Sheet.png
  Assets/Resurrection-Chamber-Production-Sheet.png
  Assets/Crystal-of-Life-State-Sheet.png
  Assets/Temple-Clothing-Evolution-Sheet.png
  Assets/Seraphine-character-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
