SBL 1.0 resolved page rendering package
Render target: CH9-P028
Entry file: CH9-P028.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Resurrection-Circle-State-Sheet.png
  Assets/Resurrection-Watch-Alpha.png
  Assets/Chamber-Log-Prop-Sheet.png
  Assets/Resurrection-Chamber-Production-Sheet.png
  Assets/Crystal-of-Life-State-Sheet.png
  Assets/Temple-of-Light-Mature-Exterior.png
  Assets/Temple-Clothing-Evolution-Sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
