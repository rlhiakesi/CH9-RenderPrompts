SBL 1.0 resolved page rendering package
Render target: CH9-P025
Entry file: CH9-P025.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zorna-canonical-character-specification(1).txt
  Assets/Zorna-expression-sheet.png
  Assets/Zorna-character-sheet.png
  Assets/Delti-Character-Sheet.png
  Assets/Temple-Clothing-Evolution-Sheet.png
  Assets/Temple-of-Light-Evolution-Sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
